# What's For Breakfast?
A simple website that gives you suggestions for what to eat in the morning.