# Daft Pad.

A little webpage that allows you to play with the samples from the Daft Punk song "Harder, Better, Faster, Stronger."

[Visit it here](ollybritton.com/harder-better-faster-stronger)
