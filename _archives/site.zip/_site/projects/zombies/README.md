# Sir Zombles.
*Ha-ha? Get it... Sir... Sir model... ha-ha... ha. Ha.*

Sir Zombles is an adjustable model of a zombie epidemic. It is done using the SIR model, but it is tweaked to allow the dead to come back to life as zombies.

Try it out. Please.

To mess with the starting percentages, you'll need to download it and edit them in the `data.js` file.
