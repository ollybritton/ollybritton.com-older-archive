# Midi To Sonic Pi

Website here: [https://ollybritton.github.io/Midi-To-Sonic-Pi-Website/](https://ollybritton.github.io/Midi-To-Sonic-Pi-Website/)
