var body = document.getElementsByTagName('body');
